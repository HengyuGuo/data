
# NOSQL - Key/Value Pair Storage Manage Example - Shore DB SM (Release 2.0) + Java NIO

    http://research.cs.wisc.edu/shore/      (Archived Site)
    http://research.cs.wisc.edu/shore-mt/   (New Site)

    http://www.eclipse.org/aspectj/                                 (Using AspectJ 1.8)
    https://eclipse.org/aspectj/doc/next/devguide/ajc-ref.html      (AspectJ Compiler)
    https://eclipse.org/aspectj/docs.php                            (AspectJ Documentation)
    https://eclipse.org/aspectj/doc/released/devguide/index.html    (AspectJ Dev Guide/Tools)

    http://www.tutorialspoint.com/java/
    http://www.tutorialspoint.com/java/java_networking.htm
    https://docs.oracle.com/javase/tutorial/
    https://docs.oracle.com/javase/tutorial/networking/index.html

    http://www.javaworld.com/article/2882984/core-java/nio2-cookbook-part-1.html
    http://www.javaworld.com/article/2899694/core-java/nio-2-cookbook-part-2.html
    http://www.javaworld.com/article/2928805/core-java/nio-2-cookbook-part-3.html
    
    

    