
import java.io.* ;

 public class PageException extends IOException {
 }
