

 public class PageFullException extends PageException {
 }
