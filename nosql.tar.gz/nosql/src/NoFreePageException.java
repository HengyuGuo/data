
 public class NoFreePageException extends PageException {
 }
